import requests
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import socket
import whois
import ssl
import urllib3
from requests.exceptions import RequestException
from urllib3.exceptions import InsecureRequestWarning
import tldextract

urllib3.disable_warnings(InsecureRequestWarning)

def get_ip_info(url):
    try:
        domain = urlparse(url).netloc
        ip_address = socket.gethostbyname(domain)
        return ip_address
    except Exception as e:
        print(f"Ошибка получения IP: {e}")
        return None

def get_domain_info(url):
    try:
        domain = urlparse(url).netloc
        domain_info = whois.whois(domain)
        # Выводим только основные поля информации о домене
        short_info = {
            'domain': domain_info.domain,
            'registrar': domain_info.registrar,
            'creation_date': domain_info.creation_date,
            'expiration_date': domain_info.expiration_date,
            'name_servers': domain_info.name_servers,
            'status': domain_info.status,
            'updated_date': domain_info.updated_date,
        }
        return short_info
    except Exception as e:
        print(f"Ошибка получения информации о домене: {e}")
        return None

def get_cookies(url):
    try:
        response = requests.get(url, verify=False) # Ignore SSL errors
        return response.cookies.get_dict()
    except Exception as e:
        print(f"Ошибка получения cookies: {e}")
        return None

def get_links(url, limit=5):
    links = []
    try:
        response = requests.get(url, verify=False) # Ignore SSL errors
        soup = BeautifulSoup(response.text, 'html.parser')
        for a in soup.find_all('a', href=True):
            if len(links) < limit:
                links.append(a['href'])
            else:
                break
        return links
    except Exception as e:
        print(f"Ошибка получения ссылок: {e}")
        return []

def get_title(url):
    try:
        response = requests.get(url, verify=False) # Ignore SSL errors
        soup = BeautifulSoup(response.text, 'html.parser')
        title = soup.title.string if soup.title else "Title not found"
        return title.strip()
    except Exception as e:
        print(f"Ошибка получения заголовка: {e}")
        return None

def get_meta_description(url):
    try:
        response = requests.get(url, verify=False) # Ignore SSL errors
        soup = BeautifulSoup(response.text, 'html.parser')
        meta_description = soup.find('meta', property='description')
        return meta_description['content'] if meta_description else "Description not found"
    except Exception as e:
        print(f"Ошибка получения мета-описания: {e}")
        return None

def get_robots_txt(url):
    try:
        robots_url = urljoin(url, "/robots.txt")
        response = requests.get(robots_url, verify=False)
        response.raise_for_status() # Raise an exception for bad status codes
        return response.text
    except RequestException as e:
        print(f"Ошибка получения robots.txt: {e}")
        return None
    except Exception as e:
        print(f"Unknown error getting robots.txt: {e}")
        return None


def get_ssl_info(url):
    try:
        parsed = urlparse(url)
        context = ssl.create_default_context()
        with socket.create_connection((parsed.hostname, 443)) as sock:
            with context.wrap_socket(sock, server_hostname=parsed.hostname) as ssock:
                cert = ssock.getpeercert()
                return cert
    except Exception as e:
        print(f"Ошибка получения информации SSL: {e}")
        return None

from urllib.parse import urljoin
if __name__ == "__main__":
    website_url = input("Введите URL сайта (например, https://example.com): ")

    # Информация о домене
    extracted = tldextract.extract(website_url)
    print(f"Domain: {extracted.domain}")
    print(f"Suffix: {extracted.suffix}")

    ip_info = get_ip_info(website_url)
    if ip_info:
        print(f"IP адрес сайта: {ip_info}")

    domain_info = get_domain_info(website_url)
    if domain_info:
        print("\nИнформация о домене:")
        for key, value in domain_info.items():
            print(f"{key}: {value}")

    cookies = get_cookies(website_url)
    if cookies:
        print("\nCookies сайта:")
        for key, value in cookies.items():
            print(f"{key}: {value}")

    links = get_links(website_url, limit=5)
    if links:
        print("\nСсылки на сайте:")
        for link in links:
            print(link)

    title = get_title(website_url)
    if title:
        print(f"\nЗаголовок страницы: {title}")

    meta_description = get_meta_description(website_url)
    if meta_description:
        print(f"\nМета-описание: {meta_description}")

    robots_txt = get_robots_txt(website_url)
    if robots_txt:
        print("\nrobots.txt:")
        print(robots_txt)

    ssl_info = get_ssl_info(website_url)
    if ssl_info:
        print("\nИнформация SSL:")
        import pprint
        pprint.pprint(ssl_info)
