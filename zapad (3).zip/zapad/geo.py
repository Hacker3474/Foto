import re
import os
from colorama import Fore, init as colorama_init

phone_pattern = re.compile(r'\b(?:\+7|8)-?\d{3}-?\d{3}-?\d{2}-?\d{2}\b')

def find_phone_numbers_in_file(file_path, phone_number):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line_number, line in enumerate(file, start=1):
                if phone_number in line:
                    print(f"{Fore.RED}[+] Найдена Геолакация в файле {file_path}, Информация {line_number}: {line.strip()}")
    except Exception as e:
        print(f"Ошибка при чтении файла {file_path}: {e}")

def find_phone_numbers_in_directory(directory, phone_number):
    for root, dirs, files in os.walk(directory):
        for file_name in files:
            file_path = os.path.join(root, file_name)
            find_phone_numbers_in_file(file_path, phone_number)

if __name__ == "__main__":
    directory_to_search = "gibbbd"  # Фиксированная директория для поиска
    phone_number = input(f"{Fore.RED}[+] Введите Геолакацию   для поиска: ")
    find_phone_numbers_in_directory(directory_to_search, phone_number)
  