import socket
import requests

def get_ip_info(ip_address):

  try:
    response = requests.get(f"http://ip-api.com/json/{ip_address}")
    response.raise_for_status()  
    data = response.json()
    return data
  except requests.exceptions.RequestException as e:
    print(f"Ошибка при запросе к API: {e}")
    return None

def print_ip_info(ip_info):
  if not ip_info:
    print("Информация об IP-адресе не найдена.")
    return

  print("Информация об IP-адресе:")
  print(f"  IP-адрес: {ip_info.get('query', 'N/A')}")
  print(f"  Страна: {ip_info.get('country', 'N/A')}")
  print(f"  Город: {ip_info.get('city', 'N/A')}")
  print(f"  Регион: {ip_info.get('regionName', 'N/A')}")
  print(f"  Почтовый индекс: {ip_info.get('zip', 'N/A')}")
  print(f"  Широта: {ip_info.get('lat', 'N/A')}")
  print(f"  Долгота: {ip_info.get('lon', 'N/A')}")
  print(f"  Часовой пояс: {ip_info.get('timezone', 'N/A')}")
  print(f"  Провайдер: {ip_info.get('isp', 'N/A')}")
  print(f"  Организация: {ip_info.get('org', 'N/A')}")
  print(f"  AS: {ip_info.get('as', 'N/A')}")

if __name__ == "__main__":
  ip_address = input("Введите IP-адрес: ")
  ip_info = get_ip_info(ip_address)
  print_ip_info(ip_info)