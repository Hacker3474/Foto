import os
os.system("clear")
try:

    from pystyle import Colors, Write

    import time

except:

    print("Не найдены библиотеки! \n Пропишите pip install pystyle")



def password():

    password_check = Write.Input("Нажмите Enter для продолжения..", Colors.blue_to_purple, interval=0.005)

    if password_check == '':

        main()

    else:

        Write.Print("Не корректный пароль ", Colors.yellow_to_red, interval=0.005)

        password()

def main():

    banner = '''



██████╗ ██╗███████╗ ██████╗ ██████╗ ██████╗ ██████╗     

██╔══██╗██║██╔════╝██╔════╝██╔═══██╗██╔══██╗██╔══██╗    

██║  ██║██║███████╗██║     ██║   ██║██████╔╝██║  ██║    

██║  ██║██║╚════██║██║     ██║   ██║██╔══██╗██║  ██║    

██████╔╝██║███████║╚██████╗╚██████╔╝██║  ██║██████╔╝    

╚═════╝ ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝     

                                                        





    '''

    Write.Print(banner, Colors.yellow_to_red, interval=0.005)

    searcher()



def searcher():

    def discord_check(bd, discord_search):

        Found = False

        with open(bd, 'r', encoding='UTF-8') as file:

            lines = file.readlines()



        for line in lines:

            data = line.strip().split(',')

            if len(data) >= 2:

                discord_name = data[1]

                if discord_search in discord_name:

                    id = data[0]

                    discord_slug = data[2]

                    discord_flags = data[3]

                    role = data[4]

                    verified = data[5]

                    views = data[6]

                    email = data[7]

                    about = data[8]

                    Write.Print(f'''



    │Discord:

    │ID: {id}

    │Slug: {discord_slug}

    │USERNAME: {discord_flags}

    │LASTNAME: {role}

    │FIRSTNAME:  {verified}

    │{views}

    │{email} 

    │{about}

    Enter To return

                    ''', Colors.blue_to_purple, interval=0.005)

                    Found = True

                    a = input()

                    main()



    def discord_check2(bd2, discord_search):

        Found = False

        with open(bd2, 'r', encoding='UTF-8') as file:

            lines = file.readlines()



        for line in lines:

            data = line.strip().split(',')

            if len(data) >= 2:

                discord_name = data[1]

                if discord_search in discord_name:

                    id = data[0]

                    discord_slug = data[2]

                    discord_flags = data[3]

                    role = data[4]

                    verified = data[5]

                    views = data[6]

                    email = data[7]

                    about = data[8]

                    Write.Print(f'''



    │Discord:

    │ID: {id}

    │Slug: {discord_slug}

    │USERNAME: {discord_flags}

    │LASTNAME: {role}

    │FIRSTNAME:  {verified}

    │{views}

    │{email} 

    │{about}

    Enter To return

                    ''', Colors.blue_to_purple, interval=0.005)

                    Found = True

                    a = input()

                    main()

        if not Found:

            Write.Print("Ничего не найдено", Colors.blue_to_purple, interval=0.005)

            time.sleep(2)

            main()



    bd = 'discord.csv'

    discord_search = Write.Input("Enter discord --> ", Colors.yellow_to_red, interval=0.005)

    discord_check(bd, discord_search)

    bd2 = 'discord1.csv'

    discord_check2(bd2, discord_search)

if __name__ == '__main__':

    password()