# DECODED BY HYPER X SQUAD >>> TOP 1 

import webbrowser
from pystyle import Colors, Colorate

def znanij_search():
    task = input("Введите свое задание для поиска на сайте ЗНАНИЕ: ")
    print(Colorate.Vertical(Colors.red_to_white, f"Задание для поиска: {task}"))
    webbrowser.open("https://znanija.com/")
    print(Colorate.Vertical(Colors.red_to_white, "Программа завершена."))
    exit()

def calculator():
    print(Colorate.Vertical(Colors.red_to_white, "=== Калькулятор ==="))
   

    expression = input("Введите выражение: ")

    if expression.lower() == 'exit':
        return

    try:
        result = eval(expression)
        print(Colorate.Vertical(Colors.red_to_white, f"Результат: {result}"))
    except ZeroDivisionError:
        print(Colorate.Vertical(Colors.red_to_white, "Ошибка: деление на ноль."))
    except Exception as e:
        print(Colorate.Vertical(Colors.red_to_white, f"Ошибка: {e}"))

    print(Colorate.Vertical(Colors.red_to_white, "Программа завершена."))
    exit()

def main():
    while True:
        print(Colorate.Vertical(Colors.red_to_white, "Выберите тип поиска ГДЗ:"))
        print(Colorate.Vertical(Colors.red_to_white, "1. Поиск по ЗНАНИЙ"))
        print(Colorate.Vertical(Colors.red_to_white, "2. Поиск по КАЛЬКУЛЯТОРУ"))
        print(Colorate.Vertical(Colors.red_to_white, "0. Выход"))

        choice = input("Введите номер выбора: ").strip()

        if choice == '1':
            znanij_search()
        elif choice == '2':
            calculator()
        elif choice == '0':
            print(Colorate.Vertical(Colors.red_to_white, "Выход из программы."))
            break
        else:
            print(Colorate.Vertical(Colors.red_to_white, "Неверный выбор."))

if __name__ == "__main__":
    main()
