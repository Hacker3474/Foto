from banner import banner
from pystyle import *
import os
import re
import csv
import os
import subprocess
import threading
import requests
import pystyle
from pystyle import *
import time

COLOR_CODE = {
    "RESET": "\033[0m",  
    "UNDERLINE": "\033[04m", 
    "GREEN": "\033[32m",     
    "YELLOW": "\033[93m",    
    "RED": "\033[31m",       
    "CYAN": "\033[36m",     
    "BOLD": "\033[01m",        
    "PINK": "\033[95m",
    "URL_L": "\033[36m",       
    "LI_G": "\033[92m",      
    "F_CL": "\033[0m",
    "DARK": "\033[90m",     
}
a=input("Введи текстовый пароль для запуска программы:")
if a!="kil":
	print("Пороль Верен Програма Работает")


print(Colorate.Horizontal(Colors.yellow_to_red, Center.XCenter(banner)))
    
select = input(f'{COLOR_CODE["YELLOW"]}[+]{COLOR_CODE["YELLOW"]}Выбор всегда за тобой>{COLOR_CODE["RED"]} ')
if select == '1':
  os.system("python poisk.py") # Запуск программы poisk.py
elif select == '2':
    os.system("python nomer.py") # Запуск программы nomer.py
elif select == '3':
    os.system("python phone2.py") # Запуск программы phone2.py
elif select == '4':
    os.system("python gmail.py") # Запуск программы gmail.py
elif select == '5':
    os.system("python mail.py") # Запуск программы mail.py
elif select == '6':
    os.system("python normail.py") # Запуск программы normail.py
elif select == '7':
    os.system("python nomeraruykrkzx.py") # Запуск программы nomeraruykrkzx.py
elif select == '8':
    os.system("python nomeraruykrkzx.py") # Запуск программы nomeraruykrkzx.py
elif select == '9':
    os.system("python nomeraruykrkzx.py") # Запуск программы nomeraruykrkzx.py
elif select == '10':
    os.system("python iin.py") # Запуск программы iin.py
elif select == '11':
    os.system("python login.py") # Запуск программы login.py
elif select == '12':
    os.system("python snils.py") # Запуск программы snils.py
elif select == '13':
    os.system("python porol.py") # Запуск программы porol.py
elif select == '14':
    os.system("python pass.py") # Запуск программы pass.py
elif select == '15':
    os.system("python kart.py") # Запуск программы kart.py
elif select == '16':
    os.system("python MAC.py") # Запуск программы MAC.py
elif select == '17':
    os.system("python NLR.py") # Запуск программы NLR.py
elif select == '18':
    os.system("python gbz.py") # Запуск программы gbz.py
elif select == '20':
    os.system("python utube.py") # Запуск программы utube.py
elif select == '21':
    os.system("python steam.py") # Запуск программы steam.py
elif select == '22':
    os.system("python fiofi.py") # Запуск программы fiofi.py
elif select == '23':
    os.system("python fiofi.py") # Запуск программы fiofi.py
elif select == '24':
    os.system("python fiofi.py") # Запуск программы fiofi.py
elif select == '25':
    os.system("python yzid.py") # Запуск программы yzid.py
elif select == '26':
    os.system("python yzid.py") # Запуск программы yzid.py
elif select == '27':
    os.system("python privatka.py") # Запуск программы privatka.py
elif select == '28':
    os.system("python DISCORD.py") # Запуск программы DISCORD.py
elif select == '29':
    os.system("python site.py") # Запуск программы site.py
elif select == '30':
    os.system("python PORNO.py") # Запуск программы PORNO.py
elif select == '31':
    os.system("python numbers.py") # Запуск программы numbers.py
elif select == '32':
    os.system("python numbers.py") # Запуск программы numbers.py
elif select == '33':
    os.system("python numbers.py") # Запуск программы numbers.py
elif select == '34':
    os.system("python avito.py") # Запуск программы avito.py
elif select == '35':
    os.system("python nick.py") # Запуск программы nick.py
elif select == '36':
    os.system("python vk.py") # Запуск программы vk.py
elif select == '37':
    os.system("python biline.py") # Запуск программы biline.py
elif select == '38':
    os.system("python tele2.py") # Запуск программы tele2.py
elif select == '39':
    os.system("python mtc.py") # Запуск программы mtc.py
elif select == '40':
    os.system("python inst.py") # Запуск программы inst.py
elif select == '41':
    os.system("python fat.py") # Запуск программы fat.py
elif select == '42':
    os.system("python fat.py") # Запуск программы fat.py
elif select == '43':
    os.system("python ip.py") # Запуск программы ip.py
elif select == '44':
    os.system("python geo.py") # Запуск программы geo.py
elif select == '45':
    os.system("python nick.py") # Запуск программы nick.py
elif select == '47':
    os.system("python sber.py") # Запуск программы sber.py
elif select == '48':
    os.system("python poisk.py") # Запуск программы poisk.py
elif select == '49':
    print("скорооооо") 
elif select == '50':
    print("скороо") 
elif select == '51':
    os.system("python poisk.py") # Запуск программы poisk.py
elif select == '55':
from dddos import dos
    dos()
elif select == '56':
    os.system("python Ddoss.py") # Запуск программы Ddoss.py
elif select == '57':
    os.system("python DDos.py") # Запуск программы DDos.py
elif select == '58':
    os.system("python snos.tg.py") # Запуск программы snos.tg.py
elif select == '59':
    os.system("python snos.tgk.py") # Запуск программы snos.tgk.py
elif select == '60':
    os.system("python snoserprivate.py") # Запуск программы snoserprivate.py
elif select == '61':
    print("sooon") 
elif select == '62':
    os.system("python spam.py") # Запуск программы spam.py
elif select == '63':
    os.system("python razban.py") # Запуск программы razban.py
elif select == '64':
    os.system("python ports.py") # Запуск программы ports.py
elif select == '65':
    os.system("python WEBCRAWLER.py") # Запуск программы WEBCRAWLER.py
elif select == '66':
    os.system("python ii.py") # Запуск программы ii.py
elif select == '67':
    os.system("python FelixLox.py") # Запуск программы FelixLox.py
elif select == '68':
    os.system("python swat.py") # Запуск программы swat.py
elif select == '69':
    os.system("python донос.py") # Запуск программы донос.py