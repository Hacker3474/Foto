import requests
from bs4 import BeautifulSoup

def web_crawler(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        links = []

        for link in soup.find_all('a', href=True):
            links.append(link['href'])

        return links

    except requests.exceptions.RequestException as e:
        return f"Ошибка: {e}"

url = input("Введите URL для обхода: ")
links = web_crawler(url)

if isinstance(links, list):
    print("Найденные ссылки:")
    for link in links:
        print(link)
else:
    print(links)
