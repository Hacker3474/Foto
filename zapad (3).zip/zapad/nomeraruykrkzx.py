



import os
import time
import glob
from getpass import getpass
from pystyle import Colors, Colorate, Center

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']


def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()

        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80:
                            if i < len(sdata):
                                key = sdata[i].replace(' ', '')
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'

                                if key:
                                    key_colored = Colorate.Horizontal(Colors.white_to_green, key)
                                    found_data.append(('├ ' + key_colored + ': ' + val, '├ ' + key + ': ' + val))


                    found_data = [line for line in found_data if ': не найден' not in line[1]]

                    if found_data:
                        found_data.insert(0, ('╭━━━━━━━━━━━━━━━━━━━━━━━━━', '╭━━━━━━━━━━━━━━━━━━━━━━━━━'))
                        found_data.append(('╰ База данных: ' + db, '╰ База данных: ' + db))
                        found_results.append(found_data)

    except BaseException as e:
        print(Colorate.Horizontal(Colors.red_to_white, '[ + ] Ошибка: ' + str(e)))
    return found_results



def search_in_directory(directory, value, specific_db=None):
    start_time = time.time()
    all_found_results = []

    if specific_db:
        db_files = [os.path.join(directory, specific_db)]
    else:
        db_files = []
        for ext in text_formats:
            db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))

        db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']



    results_summary = []
    try:
        with open('результаты_поиска.txt', 'w', encoding='utf-8') as f:
            f.write('Поисковой запрос: ' + value + '\n')
            for db in db_files:
                found_results = dbsearch(db, value)

                if found_results:
                    all_found_results.extend(found_results)
                    for result in found_results:
                        for colored_line, plain_line in result:
                            print(colored_line)
                            f.write(plain_line + '\n')
                        print('\n')
                        f.write('\n')



    except Exception as ex:
      print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time

        summary_text = f'\nПоисковой запрос: {value}\nВсего найдено результатов: {len(all_found_results)}\n'

        if elapsed_time > 60:
            summary_text += f'Затраченное время: {elapsed_time / 60:.2f} минут\n'
        else:
            summary_text += f'Затраченное время: {elapsed_time:.2f} секунд\n'

        print(Colorate.Horizontal(Colors.white_to_green, summary_text))


        try:
            with open('результаты_поиска.txt', 'r', encoding='utf-8') as f:
                content = f.read()
            with open('результаты_поиска.txt', 'w', encoding='utf-8') as f:
                f.write(summary_text)
                f.write(content)


        except Exception as ex:
          print(ex)






def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')


def menu():

    banner = """
═════════════════════════════════════════════════════════════⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣸⠒⠠⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⡇⠀⠀⠀⠑⠄⡀⠀⠀⠀⣀⠀⠀⠀
⠃⠀⠀⠀⠀⠀⢈⣵⣦⢸⣿⡧⠀⠀
⠀⠀⠀⠀⠀⠀⣼⣿⣿⣾⢏⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢿⣼⣿⢟⣷⣷⣆⠀
⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⡿⠈⢆    {помни о тех кто был стобой до конца}
⠀⠀⠀⠀⠀⢰⢸⣿⣿⣿⣿⠇⠀⠈   веди любой номер пример: +7 +380 +7кзх             
⠀⠀⠀⠀⠀⢸⢸⣿⣿⣿⡇⠀⠀⠀            
⠀⠀⠀⠀⠀⡈⣼⣿⣿⣿⡇⠀⠀⠀
⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⡇⠀⠀⠀
⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⠀⠀⠀
⠀⠀⠀⠾⢿⣿⣿⠿⠿⣿⡿⠀⠀⠀
 ═════════════════════════════════════════════════════════════
 """

    while True:
        clear_console()
        print(Colorate.Horizontal(Colors.white_to_blue, Center.XCenter(banner)))
        print(Colorate.Horizontal(Colors.white_to_blue, '1. Поиск по всем БД'))

        choice = input(Colorate.Horizontal(Colors.white_to_blue, '\nВыберите опцию: '))

        if choice == '0':
            return

        value = input(Colorate.Horizontal(Colors.white_to_blue, '\nВведите поисковой запрос: '))

        if choice == '9999':
            directory = input(Colorate.Horizontal(Colors.white_to_blue, 'Введите путь к директории: '))
            db_name = input(Colorate.Horizontal(Colors.white_to_red, 'Введите имя базы данных: '))
            search_in_directory(directory, value, specific_db=db_name)
        elif choice == '1':
            directory = input(Colorate.Horizontal(Colors.white_to_blue, 'Введите путь к директории: '))
            search_in_directory(directory, value)
        elif choice == '9999':
            db_name = input(Colorate.Horizontal(Colors.white_to_blue, 'Введите имя базы данных: '))
            search_in_directory(os.getcwd(), value, specific_db=db_name)
        elif choice == '9999':
            search_in_directory(os.getcwd(), value)
        else:
            print(Colorate.Horizontal(Colors.white_to_blue, 'Неверная опция. Попробуйте еще раз.'))

        input(Colorate.Horizontal(Colors.white_to_blue, '\nНажмите Enter, чтобы вернуться в меню...'))


if __name__ == '__main__':
        clear_console()
        menu()