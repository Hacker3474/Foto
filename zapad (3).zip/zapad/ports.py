import socket
from datetime import datetime
import pystyle
from pystyle import *

# Функция для сканирования порта
def scan_port(ip, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)
    try:
        s.connect((ip, port))
        return True
    except:
        return False
    finally:
        s.close()

# Основная функция для сканирования диапазона портов
def port_scan(ip):
    pystyle.Write.Print(f"Сканирование {ip} на открытые порты (ожидаемое время ~2 минуты)...", pystyle.Colors.red_to_white, interval = 0.0005)
    start_time = datetime.now()
    open_ports = []

    # Диапазон портов для сканирования
    for port in range(1, 1025):
        if scan_port(ip, port):
            open_ports.append(port)

    end_time = datetime.now()
    total_time = end_time - start_time

    pystyle.Write.Print(f"\nСканирование завершено за {total_time}\n", pystyle.Colors.red_to_white, interval = 0.0005)
    
    if open_ports:
        pystyle.Write.Print("Открытые порты:", pystyle.Colors.red_to_white, interval = 0.0005)
        for port in open_ports:
            pystyle.Write.Print(f"Порт {port} открыт", pystyle.Colors.red_to_white, interval = 0.0005)
    else:
        pystyle.Write.Print("Открытых портов не найдено", pystyle.Colors.red_to_white, interval = 0.0005)

    pystyle.Write.Input("\nНажмите Enter для возврата в меню...", pystyle.Colors.red_to_white, interval = 0.0005)

if __name__ == "__main__":
    target_ip = pystyle.Write.Input("Введите IP-адрес для сканирования: ", pystyle.Colors.red_to_white, interval = 0.0005)
    port_scan(target_ip)
    clear_console()
    main()